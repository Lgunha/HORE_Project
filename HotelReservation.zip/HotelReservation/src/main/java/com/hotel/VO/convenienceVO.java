package com.hotel.VO;

public class convenienceVO {
	private String detailAddr_conv;
	private String conv;
	
	public String getDetailAddr_conv() {
		return detailAddr_conv;
	}
	public void setDetailAddr_conv(String detailAddr_conv) {
		this.detailAddr_conv = detailAddr_conv;
	}
	public String getConv() {
		return conv;
	}
	public void setConv(String conv) {
		this.conv = conv;
	}
}
