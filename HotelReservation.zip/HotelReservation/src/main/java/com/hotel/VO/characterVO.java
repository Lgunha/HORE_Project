package com.hotel.VO;

public class characterVO {
	private String detailAddr_hotel_character;
	private String id_user_character;
	private String character;
	private int count_cha;
	public int getCount_cha() {
		return count_cha;
	}
	public void setCount_cha(int count_cha) {
		this.count_cha = count_cha;
	}
	public String getCharacter() {
		return character;
	}
	public void setCharacter(String character) {
		this.character = character;
	}
	public String getDetailAddr_hotel_character() {
		return detailAddr_hotel_character;
	}
	public void setDetailAddr_hotel_character(String detailAddr_hotel_character) {
		this.detailAddr_hotel_character = detailAddr_hotel_character;
	}
	public String getId_user_character() {
		return id_user_character;
	}
	public void setId_user_character(String id_user_character) {
		this.id_user_character = id_user_character;
	}
}
