package com.hotel.VO;

public class hotelVO {
	private String bigAddr_hotel;
	private String detailAddr_hotel;
	private String name_hotel;
	private String id_hotel;
	private String img_hotel;
	private String park_hotel;
	private String category_hotel;
	
	private String checkIn_hotel;
	private String checkOut_hotel;
	
	private String[] character;
	
	
	public String[] getCharacter() {
		return character;
	}
	public void setCharacter(String[] character) {
		this.character = character;
	}
	public String getCheckIn_hotel() {
		return checkIn_hotel;
	}
	public void setCheckIn_hotel(String checkIn_hotel) {
		this.checkIn_hotel = checkIn_hotel;
	}
	public String getCheckOut_hotel() {
		return checkOut_hotel;
	}
	public void setCheckOut_hotel(String checkOut_hotel) {
		this.checkOut_hotel = checkOut_hotel;
	}
	public String getCategory_hotel() {
		return category_hotel;
	}
	public void setCategory_hotel(String category_hotel) {
		this.category_hotel = category_hotel;
	}
	public String getBigAddr_hotel() {
		return bigAddr_hotel;
	}
	public void setBigAddr_hotel(String bigAddr_hotel) {
		this.bigAddr_hotel = bigAddr_hotel;
	}
	public String getDetailAddr_hotel() {
		return detailAddr_hotel;
	}
	public void setDetailAddr_hotel(String detailAddr_hotel) {
		this.detailAddr_hotel = detailAddr_hotel;
	}
	public String getName_hotel() {
		return name_hotel;
	}
	public void setName_hotel(String name_hotel) {
		this.name_hotel = name_hotel;
	}
	public String getId_hotel() {
		return id_hotel;
	}
	public void setId_hotel(String id_hotel) {
		this.id_hotel = id_hotel;
	}
	public String getImg_hotel() {
		return img_hotel;
	}
	public void setImg_hotel(String img_hotel) {
		this.img_hotel = img_hotel;
	}
	public String getPark_hotel() {
		return park_hotel;
	}
	public void setPark_hotel(String park_hotel) {
		this.park_hotel = park_hotel;
	}
}
